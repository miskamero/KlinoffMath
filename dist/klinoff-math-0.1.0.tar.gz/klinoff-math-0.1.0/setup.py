from setuptools import setup

setup(
    name='klinoff-math',
    version='0.1.0',
    description='A simple klinoff math library',
    author='Klinoff TMS',
    py_modules=['klinoffmath'],
)